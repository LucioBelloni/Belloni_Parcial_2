
package utilidad;


public interface CSVSerializable {
    String toCSV();
}
